import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "clients.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS clients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero INTEGER UNIQUE,
            nom TEXT NOT NULL,
            identifiant TEXT NOT NULL UNIQUE,
            telephone TEXT NOT NULL,
            gmail TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()