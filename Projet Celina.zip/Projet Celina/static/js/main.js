/* ── Toast notifications ── */
function showToast(message, type = "success") {
  let container = document.querySelector(".toast-container");
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

/* ── API helpers ── */
async function apiGet(url) {
  const res = await fetch(url);
  return res.json();
}

async function apiPost(url, data) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
  return res.json();
}

async function apiPut(url, data) {
  const res = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
  return res.json();
}

async function apiDelete(url) {
  const res = await fetch(url, { method: "DELETE" });
  return res.json();
}

/* ── Render table rows (liste seule, read-only) ── */
function renderClientsTable(clients, tbodyId, readOnly = false) {
  const tbody = document.getElementById(tbodyId);
  tbody.innerHTML = "";

  if (clients.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5">
          <div class="empty-state">
            <div class="empty-icon">👥</div>
            <p>Aucun client enregistré pour le moment.</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  clients.forEach(c => {
    const tr = document.createElement("tr");
    tr.dataset.id = c.id;
    tr.innerHTML = `
      <td><span class="badge-num">#${c.numero}</span></td>
      <td>${escHtml(c.nom)}</td>
      <td>${escHtml(c.identifiant)}</td>
      <td>${escHtml(c.telephone)}</td>
      <td>${escHtml(c.gmail)}</td>
      ${!readOnly ? `
      <td>
        <div style="display:flex;gap:0.5rem;">
          <button class="btn btn-ghost btn-sm" onclick="openEditModal(${c.id})">✏️ Modifier</button>
          <button class="btn btn-danger btn-sm" onclick="confirmDelete(${c.id}, '${escHtml(c.nom)}')">🗑️ Supprimer</button>
        </div>
      </td>` : ""}
    `;
    tbody.appendChild(tr);
  });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}