from flask import Blueprint, request, jsonify, render_template
from services.client_service import ClientService

client_bp = Blueprint("client", __name__, url_prefix="/clients")
service = ClientService()


@client_bp.route("/liste")
def liste():
    return render_template("liste_clients.html")


@client_bp.route("/ajouter")
def ajouter():
    return render_template("ajouter_client.html")


@client_bp.route("/gerer")
def gerer():
    return render_template("gerer_clients.html")


# ── API JSON ──────────────────────────────────────────────

@client_bp.route("/api/all", methods=["GET"])
def api_get_all():
    clients = service.get_all_clients()
    return jsonify([c.to_dict() for c in clients])


@client_bp.route("/api/add", methods=["POST"])
def api_add():
    data = request.get_json()
    result = service.add_client(
        nom=data.get("nom", ""),
        identifiant=data.get("identifiant", ""),
        telephone=data.get("telephone", ""),
        gmail=data.get("gmail", "")
    )
    return jsonify(result)


@client_bp.route("/api/update/<int:client_id>", methods=["PUT"])
def api_update(client_id):
    data = request.get_json()
    result = service.update_client(
        client_id=client_id,
        nom=data.get("nom", ""),
        identifiant=data.get("identifiant", ""),
        telephone=data.get("telephone", ""),
        gmail=data.get("gmail", "")
    )
    return jsonify(result)


@client_bp.route("/api/delete/<int:client_id>", methods=["DELETE"])
def api_delete(client_id):
    result = service.delete_client(client_id)
    return jsonify(result)