from repositories.client_repository import ClientRepository

repository = ClientRepository()


class ClientService:

    def get_all_clients(self):
        return repository.get_all()

    def get_client_by_id(self, client_id):
        return repository.get_by_id(client_id)

    def add_client(self, nom, identifiant, telephone, gmail):
        nom = nom.strip()
        identifiant = identifiant.strip()
        telephone = telephone.strip()
        gmail = gmail.strip()

        if not nom or not identifiant or not telephone or not gmail:
            return {"success": False, "message": "Tous les champs sont obligatoires."}

        if repository.identifiant_exists(identifiant):
            return {"success": False, "message": "Cet identifiant est déjà utilisé."}

        repository.add(nom, identifiant, telephone, gmail)
        return {"success": True, "message": "Client ajouté avec succès."}

    def update_client(self, client_id, nom, identifiant, telephone, gmail):
        nom = nom.strip()
        identifiant = identifiant.strip()
        telephone = telephone.strip()
        gmail = gmail.strip()

        if not nom or not identifiant or not telephone or not gmail:
            return {"success": False, "message": "Tous les champs sont obligatoires."}

        if repository.identifiant_exists(identifiant, exclude_id=client_id):
            return {"success": False, "message": "Cet identifiant est déjà utilisé par un autre client."}

        repository.update(client_id, nom, identifiant, telephone, gmail)
        return {"success": True, "message": "Client modifié avec succès."}

    def delete_client(self, client_id):
        client = repository.get_by_id(client_id)
        if not client:
            return {"success": False, "message": "Client introuvable."}
        repository.delete(client_id)
        return {"success": True, "message": "Client supprimé et numéros mis à jour."}