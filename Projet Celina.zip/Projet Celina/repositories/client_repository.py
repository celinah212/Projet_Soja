from database.db import get_connection
from models.client import Client


class ClientRepository:

    def get_all(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clients ORDER BY numero ASC")
        rows = cursor.fetchall()
        conn.close()
        return [Client.from_row(row) for row in rows]

    def get_by_id(self, client_id):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clients WHERE id = ?", (client_id,))
        row = cursor.fetchone()
        conn.close()
        return Client.from_row(row) if row else None

    def add(self, nom, identifiant, telephone, gmail):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COALESCE(MAX(numero), 0) + 1 FROM clients")
        next_numero = cursor.fetchone()[0]
        cursor.execute(
            "INSERT INTO clients (numero, nom, identifiant, telephone, gmail) VALUES (?, ?, ?, ?, ?)",
            (next_numero, nom, identifiant, telephone, gmail)
        )
        conn.commit()
        conn.close()

    def update(self, client_id, nom, identifiant, telephone, gmail):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE clients SET nom = ?, identifiant = ?, telephone = ?, gmail = ? WHERE id = ?",
            (nom, identifiant, telephone, gmail, client_id)
        )
        conn.commit()
        conn.close()

    def delete(self, client_id):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clients WHERE id = ?", (client_id,))
        conn.commit()

        # Renumérotation après suppression
        cursor.execute("SELECT id FROM clients ORDER BY id ASC")
        rows = cursor.fetchall()
        for index, row in enumerate(rows, start=1):
            cursor.execute("UPDATE clients SET numero = ? WHERE id = ?", (index, row["id"]))
        conn.commit()
        conn.close()

    def identifiant_exists(self, identifiant, exclude_id=None):
        conn = get_connection()
        cursor = conn.cursor()
        if exclude_id:
            cursor.execute(
                "SELECT COUNT(*) FROM clients WHERE identifiant = ? AND id != ?",
                (identifiant, exclude_id)
            )
        else:
            cursor.execute("SELECT COUNT(*) FROM clients WHERE identifiant = ?", (identifiant,))
        count = cursor.fetchone()[0]
        conn.close()
        return count > 0