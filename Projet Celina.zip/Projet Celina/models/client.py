class Client:
    def __init__(self, id, numero, nom, identifiant, telephone, gmail):
        self.id = id
        self.numero = numero
        self.nom = nom
        self.identifiant = identifiant
        self.telephone = telephone
        self.gmail = gmail

    def to_dict(self):
        return {
            "id": self.id,
            "numero": self.numero,
            "nom": self.nom,
            "identifiant": self.identifiant,
            "telephone": self.telephone,
            "gmail": self.gmail
        }

    @staticmethod
    def from_row(row):
        return Client(
            id=row["id"],
            numero=row["numero"],
            nom=row["nom"],
            identifiant=row["identifiant"],
            telephone=row["telephone"],
            gmail=row["gmail"]
        )